"""Public, synthetic Chinese samples. Reference labels were user-confirmed."""
from pathlib import Path
import json
import textwrap
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont

ROOT = Path(__file__).resolve().parent
GOLD = json.loads((ROOT/'fixtures/highlight-gold.json').read_text())['cases']
# Scripted importance levels test local selection, not model ranking accuracy.
DENSITY_CASES = [
    {**GOLD[2], 'importance':'core'},
    {**GOLD[0], 'importance':'important'},
    {**GOLD[1], 'importance':'important'},
    {'quote':'消融实验发现，辅助正则项降低了重复实验的方差，但尚未验证其他数据域。','type':'finding','importance':'supporting'},
    {'quote':'在补充实验中，平均推理延迟从 24 毫秒降至 21 毫秒，硬件配置保持一致。','type':'data','importance':'supporting'},
]
# Authored regression inputs, not human labels for a real paper or AI scores.
RECALL_CASES = [
    {'quote':'研究纳入 2,481 名受试者，中位随访为 36 个月；统计范围限于完成随访者。',
     'type':'data','importance':'important'},
    {'quote':'两个互补分支分别编码局部变化与全局依赖，门控交互使二者能够随输入自适应协调。',
     'type':'innovation','importance':'core'},
    {'quote':'跨城市迁移后，季节性结构仍然稳定；这一性质在稀疏观测条件下持续存在。',
     'type':'finding','importance':'important'},
    {'quote':'当观测间隔超过七天时，细粒度结构不再可辨，当前适用范围限于较密集的采样。',
     'type':'finding','importance':'supporting'},
    {'quote':'摘要中的主要贡献是把异质变化分解为互补成分，并用统一机制解释跨域表现。',
     'type':'finding','importance':'core'},
]
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))


def create(path):
    c=canvas.Canvas(str(path),pagesize=(612,792),invariant=1)
    c.setTitle('TransYH AI highlights - synthetic, user-reviewed reference statements')
    def title(text,y=744):
        c.setFont('STSong-Light',16);c.drawString(46,y,text)
    def paragraph(text,x,y,width=42):
        c.setFont('STSong-Light',11)
        for line in textwrap.wrap(text,width=width,break_long_words=True):
            c.drawString(x,y,line);y-=18
        return y-18
    filler='此处说明样本记录方式与数据整理流程。相关内容仅用于构造版式测试，不代表本文贡献，也不应因为包含一般技术描述而标记重点。'
    title('1 背景')
    paragraph(GOLD[3]['quote']+filler*2,46,706)
    title('2 方法',550)
    paragraph(GOLD[2]['quote'],46,512,30)
    paragraph(GOLD[4]['quote']+filler*3,46,420)
    c.showPage()
    title('3 结果')
    paragraph(GOLD[0]['quote'],46,696,22)
    paragraph(filler*2,46,560,22)
    paragraph(GOLD[1]['quote'],326,696,22)
    paragraph(filler*2,326,560,22)
    c.setFont('Times-Italic',20);c.drawString(230,215,'E = mc')
    c.setFont('Times-Roman',12);c.drawString(292,224,'2')
    c.setFillColorRGB(.9,.94,.97);c.rect(46,55,520,100,fill=1,stroke=0)
    c.setStrokeColorRGB(.15,.40,.7);c.line(60,70,530,130)
    c.setFillColorRGB(0,0,0);c.showPage()
    title('4 讨论')
    paragraph('仍需跨机构验证。现有测试不能证明因果关系，也不能据此宣称适用于全部应用场景。'+filler*2,46,696)
    title('参考文献',450)
    paragraph(GOLD[5]['quote']+filler,46,410)
    c.save()
    return Path(path)


def create_density(path, counts=(0,1,3,5)):
    c=canvas.Canvas(str(path),pagesize=(612,792),invariant=1)
    c.setTitle('TransYH density fixture - synthetic 0/1/3/5 research spans')
    for count in counts:
        c.setFont('STSong-Light',16);c.drawString(46,744,'实验结果')
        c.setFont('STSong-Light',11)
        texts=[row['quote'] for row in DENSITY_CASES[:count]] or ['此处说明常规数据整理流程，不包含可标注的研究发现。']
        y=700
        for text in texts:
            for line in textwrap.wrap(text,width=32,break_long_words=True):
                c.drawString(46,y,line);y-=18
            y-=26
        c.showPage()
    c.save()
    return Path(path)


def create_recall(path):
    c=canvas.Canvas(str(path),pagesize=(612,792),invariant=1)
    c.setTitle('Contextual academic reading - synthetic recall fixture')
    c.setFont('STSong-Light',20);c.drawString(46,744,'异质变化的互补表示研究')
    c.setFont('STSong-Light',11)
    for line,y in zip(textwrap.wrap('摘要：'+RECALL_CASES[4]['quote'],width=38),range(695,620,-18)):
        c.drawString(46,y,line)
    for title,index,y in [('第二章 数据来源与研究设计',0,580),('三、双分支交互机制',1,410),
                          ('4.2 跨城市迁移与边界检验',2,240)]:
        c.setFont('STSong-Light',16);c.drawString(46,y,title)
        c.setFont('STSong-Light',11)
        for line,yy in zip(textwrap.wrap(RECALL_CASES[index]['quote'],width=38),range(y-40,y-120,-18)):
            c.drawString(46,yy,line)
    c.showPage()
    c.setFont('STSong-Light',16);c.drawString(46,744,'附录 A 补充验证')
    c.setFont('STSong-Light',11)
    for line,y in zip(textwrap.wrap(RECALL_CASES[3]['quote'],width=38),range(695,620,-18)):
        c.drawString(46,y,line)
    c.save()
    return Path(path)
